package userinterface;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class BankScenes extends Application {
    public static void main(String[] args) {
        launch( args );
    }
    
    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle( "Welcome" );
        primaryStage.show();
    
        // setting up the grid where the form belongs
    
        GridPane grid = new GridPane();
        grid.setAlignment( Pos.CENTER );
        grid.setHgap( 10 );
        grid.setVgap( 10 );
        grid.setPadding( new Insets( 25, 25, 25, 25 ) );
    
        // creating a new scene object
    
    
        // -------------- Bank Menu 1 --------------- //
    
        Text sceneTitle = new Text( "Bank Menu" );
        sceneTitle.setFont( Font.font( "Tahoma", FontWeight.NORMAL, 20 ) );
        grid.add( sceneTitle, 0, 0, 2, 1 );

//        Label userName = new Label("Name:");
//        grid.add(userName, 0, 1);
//
//        TextField userTextField = new TextField();
//        grid.add(userTextField, 1, 1);
    
        Label id = new Label( "ID:" );
        grid.add( id, 0, 2 );
    
        TextField idTextField = new TextField();
        grid.add( idTextField, 1, 2 );
    
        //A checkbox without a caption
        CheckBox cb1 = new CheckBox( "Over 18" );
        //A checkbox with a string caption
        CheckBox cb2 = new CheckBox( "Paid" );
        CheckBox cb3 = new CheckBox( "Verified" );

//        cb1.setText("First");
//        cb1.setSelected(true);
    
        grid.add( cb1, 0, 5 );
        grid.add( cb2, 1, 5 );
        grid.add( cb3, 2, 5 );

//        Label pw = new Label("Password:");
//        grid.add(pw, 0, 3);
//
//        PasswordField pwBox = new PasswordField();
//        grid.add(pwBox, 1, 3);
    
        Button btnBack = new Button( "Back" );
        HBox hbBtnBack = new HBox( 10 );
    
        Button btn = new Button( "Submit" );
        HBox hbBtn = new HBox( 10 );
    
        hbBtn.setAlignment( Pos.BOTTOM_RIGHT );
        hbBtn.getChildren().add( btnBack );
        grid.add( hbBtnBack, 0, 7 );
    
        hbBtn.setAlignment( Pos.BOTTOM_RIGHT );
        hbBtn.getChildren().add( btn );
        grid.add( hbBtn, 1, 7 );
    
        final Text actionTarget = new Text();
        grid.add( actionTarget, 1, 6 );
    
        // ---------------- END Bank Menu 1 --------------------- //
    
        // ---------------- Bank Menu 2 ----------------- //
    
    
        // ---------------- End Bank Menu 2 ------------- //
    }
}